<?php
//full control
header('Access-Control-Allow-Origin: *');
//khai bao thong tin server
$ser="localhost";
$u="root";
$p="";
$dbname="aflutter";
//thuc hien ket noi voi db
$conn=new mysqli($ser,$u,$p,$dbname);
//khai bao lenh thuc thi
$sql="select * from mytable";
//thuc thi 
$kq=$conn->query($sql);//tra ve 1 tap ket qua
while($row[]=$kq->fetch_assoc())//doc tung dong
{
    $json=json_encode($row);//chuyen du lieu thanh json
}
echo '{"products":'.$json.'}';
$conn->close();
?>